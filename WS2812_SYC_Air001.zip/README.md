# IMU_Fusion_SYC   v1.0.0

HSI 设置为24M，HCLK设置为48M

## Licence

MIT

## Author

Eason-SYC